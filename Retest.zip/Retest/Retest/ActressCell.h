//
//  ImageCollectionViewCell.h
//  Retest
//
//  Created by Yevhen Kim on 2016-07-18.
//  Copyright © 2016 Yevhen Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActressCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *actressImage;

@end
